﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Jose Gabriel Vargas Walsh
namespace SumaEsquinasMatriz
{
    internal class Program
    {
        static void Main(string[] args)
        {

            {
                // Solicicta al ususario el tamaño de la matriz
                Console.Write("Ingrese el tamaño de la matriz: ");
                int n =  int.Parse(Console.ReadLine());
                int numero;

                // Inicia la matriz y rellena con numeros sus espacios
                int[,] matrix = new int[n, n];
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        Console.Write("Ingrese un numero: ");
                        numero = int.Parse(Console.ReadLine());
                        matrix[i, j] = numero;

                    }
                }

                // suma las esquinas de la matriz
                int cornerSum = matrix[0, 0] + matrix[0, n - 1] + matrix[n - 1, 0] + matrix[n - 1, n - 1];

                // Muestra el resultado
                Console.WriteLine("La suma de las esquinas de la matriz es: " + cornerSum);
            }
            Console.WriteLine("Presione cuakquier tecla para finalizar");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}